<?php
include '../header_links.php';

include 'connection.php';



?>



<div class="overflow-x-auto relative shadow-md sm:rounded-lg">
    <table class="w-full text-sm text-left text-blue-100 dark:text-blue-100">
        <thead class="text-xs text-white uppercase bg-blue-600 border-b border-blue-400 dark:text-white">
            <tr>
                <th scope="col" class="py-3 px-6">
                    Product name
                </th>
                <th scope="col" class="py-3 px-6">
                    Color
                </th>
                <th scope="col" class="py-3 px-6">
                    Category
                </th>
                <th scope="col" class="py-3 px-6">
                    Price
                </th>
                <th scope="col" class="py-3 px-6">
                    Action
                </th>
            </tr>
        </thead>
        <tbody>
            <?php
            $select = "select * from pic";
            $query = mysqli_query($connect, $select);
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr class="bg-gray-600 border-b border-blue-400 hover:bg-blue-500">
                    <th scope="row" class="py-4 px-6 font-medium text-blue-50 whitespace-nowrap dark:text-blue-100">
                        <?php echo $data['name']; ?>
                    </th>
                    <td class="py-4 px-6">
                        <img class="w-14 h-10" src="<?php echo $data['picture']; ?>" alt="">
                    </td>
                    <td class="py-4 px-6">
                        <?php echo $data['size']; ?> MB
                    </td>
                    <td class="py-4 px-6">
                        $2999
                    </td>
                    <td class="py-4 px-6">
                        <a href="#" class="font-medium text-white hover:underline">Edit</a>
                    </td>
                </tr>
            <?php
            } //end of if condition
            ?>
        </tbody>
    </table>
</div>



<script src="https://unpkg.com/flowbite@1.5.3/dist/flowbite.js"></script>
</body>

</html>