<?php

$host = "localhost";
$user = "root";
$pass = "";
$db_name = "pic_upload";

$connect = mysqli_connect($host, $user, $pass, $db_name);

if(!$connect){
    die(mysqli_connect_error());
}

?>