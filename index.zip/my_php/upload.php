<?php
include "connection.php";

if(isset($_POST['submit'])){

    $file = $_FILES['file'];

    // echo "<pre>";
    // print_r($file);

    $file_name = $file['name'];
    // $file_full_path = $file['full_path'];
    // $file_type = $file['type'];
    $file_tmp_name = $file['tmp_name']; //firle path
    $file_error = $file['error'];
    $file_size = $file['size'];
    $file_size =round(($file_size/1024)/1024, 2);

    // echo $file_name;

    
    if($file_error==0){ //if file-error is '0'

        $extention = explode('.', $file_name);
        $extention_filter = strtolower(end($extention));
        $arr = array('jpg', 'png', 'jpeg');
        $match = in_array($extention_filter, $arr);
        
        if($match){
            $allo_file = 'upload_img/'.$file_name;
            // echo $allo_file;
            move_uploaded_file($file_tmp_name, $allo_file);
            $insert = " insert into  pic (picture, name, size) values ('$allo_file', '$file_name','$file_size')";
            $query = mysqli_query($connect, $insert);
            if($query){
                header('location: show.php');
            }
            else{
                header('location: ../index.php');
            }
        }
        else{
            header('location: ../index.php?file=extentNotMatch');
        }
    }
        
}else{
    header('location: ../index.php?problem=submit');
}

?>